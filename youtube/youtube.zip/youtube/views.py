import json
import requests
import urlparse

from django.shortcuts import render_to_response
from django.core.context_processors import csrf
from django.template import RequestContext
from django.http import HttpResponseRedirect, HttpResponse
from django.conf import settings

def linkgoogle(request):
	url = 'https://accounts.google.com/o/oauth2/auth?client_id='+settings.CLIENT_ID+'&redirect_uri=http://127.0.0.1:8000/oauth2callback&scope=https://www.googleapis.com/auth/yt-analytics.readonly&response_type=code&access_type=offline'
	return HttpResponseRedirect(url)

def callback(request):
	code = request.GET.get('code')
	print code
	payload = {'code':code,'client_id':settings.CLIENT_ID, 'client_secret':settings.CLIENT_SECRET, 'redirect_uri':'http://127.0.0.1:8000/oauth2callback','grant_type':'authorization_code'}
	response = requests.post('https://accounts.google.com/o/oauth2/token', params=payload)
	response = urlparse.parse_qs(response.text)
	print "response" + response
	access_token = response['access_token'][0]
	request.session['access_token'] = access_token
	print access_token
	# url = 'https://api.github.com/user?access_token=' + str(access_token)
	# response = requests.get(url)
	# response = response.json()
	# a = Githubprofile(user=request.user, name=response["name"], email=response["email"], 
	# 	public_repos=response["public_repos"], login=response["login"], avatar_url = response["avatar_url"], 
	# 	repos_url= response["repos_url"], html_url=response["html_url"], access_token=access_token)
	# a.save()
	# url = response["repos_url"]
	# public_repo_count = response["public_repos"]
	# response = requests.get(url)
	# repos = response.json()
	# for repo in repos:
	# 	b = Repository(user=request.user, repo_id=repo["id"], name=repo["name"], full_name=repo["full_name"],
	# 	 html_url=repo["html_url"], description=repo["description"], url=repo["url"])
	# 	b.save()
	return HttpResponse('ok')